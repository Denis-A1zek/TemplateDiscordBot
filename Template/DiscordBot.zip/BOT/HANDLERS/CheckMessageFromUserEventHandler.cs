﻿
using $safeprojectname$.Bot.Events;
using $safeprojectname$.Bot.Notifications;

namespace $safeprojectname$.Bot.Handlers
{
    public class CheckMessageFromUserEventHandler : IAsyncEventHandler<MessageReceivedFromUserEvent>
    {

        public async Task HandleAsync(MessageReceivedFromUserEvent @event)
        {
            await Console.Out.WriteLineAsync($"Написал");
        }

    }
}