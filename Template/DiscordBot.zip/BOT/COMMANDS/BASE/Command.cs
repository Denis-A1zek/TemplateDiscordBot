﻿using Discord.Interactions;

namespace $safeprojectname$.Bot.Commands
{
    public class Command : InteractionModuleBase<SocketInteractionContext>
    {
    }
}