﻿using Discord.WebSocket;

namespace $safeprojectname$.Bot.Events
{
    public class MessageReceivedFromUserEvent
    {
        public SocketMessage Message { get; set; }
    }
}